## Android Push Notification Via Dashboard Example App
Welcome to Back4App's GitHub!

In this repository you will find an example app with all steps covered at Back4App's Android Push Notification Via Dashboard Tutorial.

Don't forget to paste your Back4App App ID and Client Key in the `strings.xml` file and also to paste your Sender ID in the `manifest.xml` file and in the `Push.java` class.
